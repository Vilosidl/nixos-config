---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

#### For new checks and feature suggestions
- [ ] https://www.shellcheck.net/ (i.e. the latest commit) currently gives no useful warnings about this
- [ ] I searched through https://github.com/koalaman/shellcheck/issues and didn't find anything related

#### Here's a snippet or screenshot that shows a potential problem:

```sh
#!/bin/sh
your script here
```

#### Here's what shellcheck currently says:



#### Here's what I wanted to see:
